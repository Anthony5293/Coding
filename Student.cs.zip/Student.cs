﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Week2Activity
{
    public class Student
    {
        Student stundent1 = new Student();

        public Student()
        {
            student1.Introduce();
            Console.WriteLine("");
        }


    }
}
